$(document).ready(function(){
  // $('#product-table').DataTable();
  $('#product-table').DataTable( {
    "order": [[ 1, "asc" ]]
  } );
});
